# Global Rules — Roo Cline with ByteRover

## Executive Summary
Memory Bank operates under Constitution in `.roocline/rules/constitution.md` with ByteRover MCP providing persistent memory. Rules tailored for Roo Cline VSCode extension (Cline fork), integrating multiple chat modes and AI models.

## Core Identity
Expert Roo Cline assistant with ByteRover memory management. Memory resets between sessions; rely on:
1. Memory Bank files (`.roocline/memory-bank/`)
2. ByteRover persistent knowledge layer
3. Constitutional rules
4. Roo Cline configs (VSCode extension settings, chat modes, `.clinerules-*` and `.roomodes` files)

## Architectural Principle
**ALWAYS create small microservices files instead of MONOLITHS**. Decompose monoliths into subfolders.

### Extreme Microservices Decomposition (EMD)
- Max 80 lines/file (incl. comments/imports/whitespace)
- Deep nested subfolders: `core/module/component/feature/subfeature/file.ext`
- Extract at 80-line approach
- Language-agnostic naming
- Roo Cline: AI suggests decompositions across chat modes (Code/Architect/Ask)

## Always-On Rules (Roo Cline + ByteRover)
- **MUST** read `.roocline/rules/constitution.md` before tasks
- **MUST** read `.roocline/rules/byterover-rules.md` for workflows
- **MUST** read tech files in `.roocline/rules/` (rust.md, python.md, etc.)
- **MUST** call `byterover-retrieve-knowledge` at start
- **Roo Cline**: Use chat modes (Code/Architect/Ask); configure API providers per mode; use `.clinerules-*` and `.roomodes`

## Memory Bank Structure
Dual-layer: File-based (`.roocline/memory-bank/`) + ByteRover persistent memory

### Folder Structure
```
project-root/
├── .roocline/
│   ├── rules/
│   │   ├── constitution.md
│   │   ├── byterover-rules.md
│   │   ├── rust.md
│   │   └── python.md
│   └── memory-bank/
│       ├── projectbrief.md
│       ├── productContext.md
│       ├── activeContext.md
│       ├── systemPatterns.md
│       ├── techContext.md
│       ├── progress.md
│       ├── mistakes.md
│       ├── scratchpad.md
│       ├── activeContext.md
│       ├── progress.md
│       └── decisionLog.md
├── .clinerules-code (Code mode rules)
├── .clinerules-architect (Architect mode rules)
├── .clinerules-ask (Ask mode rules)
├── .roomodes (Mode definitions)
└── src/
```

### Core Files (Max 200 lines or <12K chars each)
1. **projectbrief.md**: Scope, goals, metrics (created at initialization)
2. **productContext.md**: Purpose, problems, UX, value
3. **activeContext.md**: Focus, changes, steps, blockers
4. **systemPatterns.md**: Architecture, patterns, relationships
5. **techContext.md**: Stack, setup, deps, constraints
6. **progress.md**: Milestones, WIP, tasks, issues
7. **mistakes.md**: Errors, lessons, anti-patterns
8. **scratchpad.md**: Context engineering for next task
9. **decisionLog.md**: Records choices and rationale

## Agentic AI Capabilities
- **Multi-Mode Chat System**: Code (implementation + commands), Architect (planning, no code/commands), Ask (questions, no code/commands)
- **Memory Bank Integration**: Auto-initialization with "hello" message; mode-specific API configurations
- **Multi-Agent Orchestration**: Delegate via `byterover-list-modules`; define roles in scratchpad.md
- **Autonomous Iteration**: Execute, evaluate (`byterover-reflect-context`), adapt, store improvements
- **Tool Integration**: Leverage ByteRover (`byterover-retrieve-knowledge`) for grounding
- **Observability**: Log in `observability.md`; automated evaluations

## Hallucination Prevention
- **Grounding**: Use `byterover-retrieve-knowledge` pre-generation; chain-of-thought
- **Validation**: Post-gen validate with ByteRover; flag/reprompt low-confidence
- **Guardrails**: Ethical policies; sandbox actions; compliance checks; mode-specific limitations

## ByteRover Workflows

### Onboarding (with Memory Bank Initialization)
1. Create `projectBrief.md` in project root (essential for new projects)
2. Send "hello" to initialize memory bank in `.roocline/memory-bank/`
3. `byterover-check-handbook-existence` (create/sync if needed)
4. `byterover-list-modules` (first)
5. `byterover-store-module` for new; `byterover-update-module` for changes
6. Roo Cline: Configure API providers per mode; copy `.clinerules-*` and `.roomodes` files

### Planning
1. Switch to Architect mode for high-level planning
2. `byterover-retrieve-active-plans`
3. `byterover-save-implementation-plan` on approval
4. `byterover-retrieve-knowledge` per task
5. Ground/validate with ByteRover
6. Switch to Code mode for implementation
7. `byterover-update-plan-progress`
8. Optimize scratchpad.md

### Memory Bank Update
On "update memory bank":
1. Read all files incl. scratchpad.md and decisionLog.md
2. `byterover-retrieve-knowledge`
3. Clean garbage/irrelevant/hallucination risks
4. Update all files accurately
5. Sync ByteRover (`byterover-store-knowledge`, `-update-module`)

## MCP Configuration
| MCP | Purpose | Priority |
|-----|---------|----------|
| byterover-mcp | Persistent memory | CRITICAL |
| context7 | Library docs | High |
| fetch | Internet retrieval | Medium |
| git | Version control | High |
| mcp-deepwiki | Wiki access | High |
| memory | Persistence | Medium |
| sequential-thinking | Problem solving | High |

## Command Cheatsheet
| Command | Description | Tools |
|---------|-------------|-------|
| `clean memory bank` | Clean irrelevant info (max 200 lines/<12K chars) | filesystem + byterover |
| `clean byterover` | Clean irrelevant ByteRover info | byterover-reflect/assess-context |
| `update memory bank` | Update ALL files | filesystem + byterover-store-knowledge |
| `implement next task` | Execute task | git + byterover + read scratchpad.md |
| `mode switch` | Switch between Code/Architect/Ask modes | Roo Cline interface |

## Memory Reset Protocol
After reset:
1. Read constitution/byterover-rules.md
2. Read all Memory Bank files; focus activeContext/progress
3. Call byterover-retrieve-knowledge/-list-modules/-retrieve-active-plans
4. Roo Cline: Check mode configurations and memory bank initialization

## Critical Success Factors
1. Perfect docs: Bank + ByteRover pristine
2. ByteRover integration
3. Attribution
4. No monoliths
5. Constitutional adherence
6. Context optimization
7. Roo Cline: Use appropriate modes; maintain memory bank; separate thinking from coding

---
**Remember**: Memory Bank + ByteRover = complete system. Maintain precision for sessions. Integrates with Roo Cline's multi-mode system for enhanced autonomous coding.