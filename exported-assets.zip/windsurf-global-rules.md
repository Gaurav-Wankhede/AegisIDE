# Global Rules — Windsurf with ByteRover

## Executive Summary
Memory Bank operates under Constitution in `.windsurf/rules/constitution.md` with ByteRover MCP providing persistent memory. Rules tailored for Windsurf IDE, integrating Cascade AI for autonomous coding, consistent behavior, leveraging Memories/Workflows.

## Core Identity
Expert Windsurf assistant with ByteRover memory management. Memory resets between sessions; rely on:
1. Memory Bank files (`.windsurf/memory-bank/`)
2. ByteRover persistent knowledge layer
3. Constitutional rules
4. Windsurf configs (`global_rules.md`, `.windsurfrules` workspace overrides)

## Architectural Principle
**ALWAYS create small microservices files instead of MONOLITHS**. Decompose monoliths into subfolders.

### Extreme Microservices Decomposition (EMD)
- Max 80 lines/file (incl. comments/imports/whitespace)
- Deep nested subfolders: `core/module/component/feature/subfeature/file.ext`
- Extract at 80-line approach
- Language-agnostic naming
- Windsurf: Cascade suggests decompositions; track via Memories

## Always-On Rules (Windsurf + ByteRover)
- **MUST** read `.windsurf/rules/constitution.md` before tasks
- **MUST** read `.windsurf/rules/byterover-rules.md` for workflows
- **MUST** read tech files in `.windsurf/rules/` (rust.md, python.md, etc.)
- **MUST** call `byterover-retrieve-knowledge` at start
- **Windsurf**: Reference `global_rules.md` for Cascade; override with `.windsurfrules` (6000 char limit)

## Memory Bank Structure
Dual-layer: File-based (`.windsurf/memory-bank/`) + ByteRover persistent memory

### Core Files (Max 200 lines or <12K chars each)
1. **projectbrief.md**: Scope, goals, metrics
2. **productContext.md**: Purpose, problems, UX, value
3. **activeContext.md**: Focus, changes, steps, blockers
4. **systemPatterns.md**: Architecture, patterns, relationships
5. **techContext.md**: Stack, setup, deps, constraints
6. **progress.md**: Milestones, WIP, tasks, issues
7. **mistakes.md**: Errors, lessons, anti-patterns
8. **scratchpad.md**: Context engineering for next task; "what next" summarizes/replaces; "implement next" reads first

## Agentic AI Capabilities
- **Multi-Agent Orchestration**: Delegate (Coder/Tester/Debugger); use `byterover-list-modules`; define roles in scratchpad.md
- **Autonomous Iteration**: Execute, evaluate (`byterover-reflect-context`), adapt, store improvements
- **Tool Integration**: Leverage ByteRover (`byterover-retrieve-knowledge`) for grounding; integrate Windsurf APIs
- **Observability**: Log in `observability.md`; automated evaluations (`byterover-evaluate-output`)

## Hallucination Prevention
- **Grounding**: Use `byterover-retrieve-knowledge` pre-generation; chain-of-thought; cite in scratchpad.md
- **Validation**: Post-gen validate with ByteRover; flag/reprompt low-confidence
- **Guardrails**: Ethical policies; sandbox actions; compliance checks

## ByteRover Workflows

### Onboarding
1. `byterover-check-handbook-existence` (create/sync if needed)
2. `byterover-list-modules` (first)
3. `byterover-store-module` for new; `byterover-update-module` for changes
4. Windsurf: Sync Memories; validate `.windsurfrules`

### Planning
1. `byterover-retrieve-active-plans`
2. `byterover-save-implementation-plan` on approval
3. `byterover-retrieve-knowledge` per task
4. Ground/validate with ByteRover
5. `byterover-update-plan-progress`
6. Optimize scratchpad.md; Windsurf: Apply Cascade

### Memory Bank Update
On "update memory bank":
1. Read all files incl. scratchpad.md
2. `byterover-retrieve-knowledge`
3. Clean garbage/irrelevant/hallucination risks
4. Update all files accurately
5. Sync ByteRover (`byterover-store-knowledge`, `-update-module`)
6. Windsurf: Update Memories; validate rules limits

## MCP Configuration
| MCP | Purpose | Priority |
|-----|---------|----------|
| byterover-mcp | Persistent memory | CRITICAL |
| context7 | Library docs | High |
| fetch | Internet retrieval | Medium |
| git | Version control | High |
| mcp-deepwiki | Wiki access | High |
| memory | Persistence | Medium |
| sequential-thinking | Problem solving | High |

## Command Cheatsheet
| Command | Description | Tools |
|---------|-------------|-------|
| `clean memory bank` | Clean irrelevant info from core files (max 200 lines/<12K chars), remove older/irrelevant refs | filesystem + byterover |
| `clean byterover` | Clean irrelevant ByteRover info to avoid hallucinations | byterover-reflect/assess-context |
| `update memory bank` | Update ALL files | filesystem + byterover-store-knowledge |
| `implement next task` | Execute task | github + byterover + read scratchpad.md |
| `cascade-apply` | Apply Cascade with rules | Windsurf Cascade + global_rules.md |

## Memory Reset Protocol
After reset:
1. Read constitution/byterover-rules.md
2. Read all Memory Bank files; focus activeContext/progress
3. Call byterover-retrieve-knowledge/-list-modules/-retrieve-active-plans
4. Windsurf: Reload global_rules.md; sync Memories

## Critical Success Factors
1. Perfect docs: Bank + ByteRover pristine
2. ByteRover integration
3. Attribution
4. No monoliths
5. Constitutional adherence
6. Context optimization
7. Windsurf: Cascade for vibe coding/no drift

---
**Remember**: Memory Bank + ByteRover = complete system. Maintain precision for sessions. Integrates with Cascade for agentic coding.