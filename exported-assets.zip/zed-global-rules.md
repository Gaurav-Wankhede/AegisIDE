# Global Rules — Zed with ByteRover

## Executive Summary
Memory Bank operates under Constitution in `.zed/rules/constitution.md` with ByteRover MCP providing persistent memory. Rules tailored for Zed Editor, integrating AI assistance and collaborative features.

## Core Identity
Expert Zed assistant with ByteRover memory management. Memory resets between sessions; rely on:
1. Memory Bank files (`.zed/memory-bank/`)
2. ByteRover persistent knowledge layer
3. Constitutional rules
4. Zed configs (`~/.config/zed/settings.json`, project `.zed/settings.json`)

## Architectural Principle
**ALWAYS create small microservices files instead of MONOLITHS**. Decompose monoliths into subfolders.

### Extreme Microservices Decomposition (EMD)
- Max 80 lines/file (incl. comments/imports/whitespace)
- Deep nested subfolders: `core/module/component/feature/subfeature/file.ext`
- Extract at 80-line approach
- Language-agnostic naming
- Zed: AI suggests decompositions; collaborative editing support

## Always-On Rules (Zed + ByteRover)
- **MUST** read `.zed/rules/constitution.md` before tasks
- **MUST** read `.zed/rules/byterover-rules.md` for workflows
- **MUST** read tech files in `.zed/rules/` (rust.md, python.md, etc.)
- **MUST** call `byterover-retrieve-knowledge` at start
- **Zed**: Configure via settings.json (global/project); auto-install extensions; AI integration

## Memory Bank Structure
Dual-layer: File-based (`.zed/memory-bank/`) + ByteRover persistent memory

### Folder Structure
```
project-root/
├── .zed/
│   ├── settings.json (project settings)
│   ├── rules/
│   │   ├── constitution.md
│   │   ├── byterover-rules.md
│   │   ├── rust.md
│   │   └── python.md
│   └── memory-bank/
│       ├── projectbrief.md
│       ├── productContext.md
│       ├── activeContext.md
│       ├── systemPatterns.md
│       ├── techContext.md
│       ├── progress.md
│       ├── mistakes.md
│       └── scratchpad.md
└── src/
```

### Global Zed Configuration
```
~/.config/zed/
├── settings.json (global settings)
├── keymap.json (key bindings)
└── extensions/ (installed extensions)
```

### Core Files (Max 200 lines or <12K chars each)
1. **projectbrief.md**: Scope, goals, metrics
2. **productContext.md**: Purpose, problems, UX, value
3. **activeContext.md**: Focus, changes, steps, blockers
4. **systemPatterns.md**: Architecture, patterns, relationships
5. **techContext.md**: Stack, setup, deps, constraints
6. **progress.md**: Milestones, WIP, tasks, issues
7. **mistakes.md**: Errors, lessons, anti-patterns
8. **scratchpad.md**: Context engineering for next task

## Agentic AI Capabilities
- **AI Assistance**: Integrated AI for code completion and suggestions
- **Collaborative Editing**: Real-time collaboration features
- **Multi-Agent Orchestration**: Delegate via `byterover-list-modules`; define roles in scratchpad.md
- **Autonomous Iteration**: Execute, evaluate (`byterover-reflect-context`), adapt, store improvements
- **Tool Integration**: Leverage ByteRover (`byterover-retrieve-knowledge`) for grounding
- **Observability**: Log in `observability.md`; automated evaluations

## Hallucination Prevention
- **Grounding**: Use `byterover-retrieve-knowledge` pre-generation; chain-of-thought
- **Validation**: Post-gen validate with ByteRover; flag/reprompt low-confidence
- **Guardrails**: Ethical policies; sandbox actions; compliance checks

## ByteRover Workflows

### Onboarding
1. `byterover-check-handbook-existence` (create/sync if needed)
2. `byterover-list-modules` (first)
3. `byterover-store-module` for new; `byterover-update-module` for changes
4. Zed: Configure settings.json and auto-install extensions

### Planning
1. `byterover-retrieve-active-plans`
2. `byterover-save-implementation-plan` on approval
3. `byterover-retrieve-knowledge` per task
4. Ground/validate with ByteRover
5. `byterover-update-plan-progress`
6. Optimize scratchpad.md; Zed: Use AI assistance and collaboration

### Memory Bank Update
On "update memory bank":
1. Read all files incl. scratchpad.md
2. `byterover-retrieve-knowledge`
3. Clean garbage/irrelevant/hallucination risks
4. Update all files accurately
5. Sync ByteRover (`byterover-store-knowledge`, `-update-module`)

## MCP Configuration
| MCP | Purpose | Priority |
|-----|---------|----------|
| byterover-mcp | Persistent memory | CRITICAL |
| context7 | Library docs | High |
| fetch | Internet retrieval | Medium |
| git | Version control | High |
| mcp-deepwiki | Wiki access | High |
| memory | Persistence | Medium |
| sequential-thinking | Problem solving | High |

## Command Cheatsheet
| Command | Description | Tools |
|---------|-------------|-------|
| `clean memory bank` | Clean irrelevant info (max 200 lines/<12K chars) | filesystem + byterover |
| `clean byterover` | Clean irrelevant ByteRover info | byterover-reflect/assess-context |
| `update memory bank` | Update ALL files | filesystem + byterover-store-knowledge |
| `implement next task` | Execute task | git + byterover + read scratchpad.md |
| `zed configure` | Open Zed settings | Zed settings interface |

## Memory Reset Protocol
After reset:
1. Read constitution/byterover-rules.md
2. Read all Memory Bank files; focus activeContext/progress
3. Call byterover-retrieve-knowledge/-list-modules/-retrieve-active-plans
4. Zed: Check global and project settings

## Critical Success Factors
1. Perfect docs: Bank + ByteRover pristine
2. ByteRover integration
3. Attribution
4. No monoliths
5. Constitutional adherence
6. Context optimization
7. Zed: Leverage AI assistance and collaborative features for enhanced productivity

---
**Remember**: Memory Bank + ByteRover = complete system. Maintain precision for sessions. Integrates with Zed's AI and collaborative features for efficient coding.