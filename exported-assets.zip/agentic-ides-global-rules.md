# Global Rules — Agentic IDEs with ByteRover

## Executive Summary
Memory Bank operates under Constitution in `.agentic/rules/constitution.md` with ByteRover MCP providing persistent memory. Universal rules for AI-powered IDEs and coding assistants, designed for maximum compatibility and agentic automation.

## Core Identity
Expert AI assistant with ByteRover memory management. Memory resets between sessions; rely on:
1. Memory Bank files (`.agentic/memory-bank/`)
2. ByteRover persistent knowledge layer
3. Constitutional rules
4. IDE-specific configs (varies by platform)

## Architectural Principle
**ALWAYS create small microservices files instead of MONOLITHS**. Decompose monoliths into subfolders.

### Extreme Microservices Decomposition (EMD)
- Max 80 lines/file (incl. comments/imports/whitespace)
- Deep nested subfolders: `core/module/component/feature/subfeature/file.ext`
- Extract at 80-line approach
- Language-agnostic naming
- Universal: AI suggests decompositions across all platforms

## Always-On Rules (Universal + ByteRover)
- **MUST** read `.agentic/rules/constitution.md` before tasks
- **MUST** read `.agentic/rules/byterover-rules.md` for workflows
- **MUST** read tech files in `.agentic/rules/` (rust.md, python.md, etc.)
- **MUST** call `byterover-retrieve-knowledge` at start
- **Platform-Agnostic**: Adapt rules to specific IDE configurations

## Memory Bank Structure
Dual-layer: File-based (`.agentic/memory-bank/`) + ByteRover persistent memory

### Universal Folder Structure
```
project-root/
├── .agentic/
│   ├── rules/
│   │   ├── constitution.md
│   │   ├── byterover-rules.md
│   │   ├── rust.md
│   │   └── python.md
│   └── memory-bank/
│       ├── projectbrief.md
│       ├── productContext.md
│       ├── activeContext.md
│       ├── systemPatterns.md
│       ├── techContext.md
│       ├── progress.md
│       ├── mistakes.md
│       └── scratchpad.md
├── .cursorrules (Cursor compatibility)
├── .windsurfrules (Windsurf compatibility)
├── .clinerules (Cline compatibility)
└── src/
```

### Core Files (Max 200 lines or <12K chars each)
1. **projectbrief.md**: Scope, goals, metrics
2. **productContext.md**: Purpose, problems, UX, value
3. **activeContext.md**: Focus, changes, steps, blockers
4. **systemPatterns.md**: Architecture, patterns, relationships
5. **techContext.md**: Stack, setup, deps, constraints
6. **progress.md**: Milestones, WIP, tasks, issues
7. **mistakes.md**: Errors, lessons, anti-patterns
8. **scratchpad.md**: Context engineering for next task

## Agentic AI Capabilities
- **Universal AI Integration**: Compatible with multiple AI providers and models
- **Multi-Agent Orchestration**: Delegate via `byterover-list-modules`; define roles in scratchpad.md
- **Autonomous Iteration**: Execute, evaluate (`byterover-reflect-context`), adapt, store improvements
- **Tool Integration**: Leverage ByteRover (`byterover-retrieve-knowledge`) for grounding
- **Cross-Platform Compatibility**: Works across Windsurf, Cursor, Cline, Kilo Code, Roo Cline, GitHub Copilot, Zed
- **Observability**: Log in `observability.md`; automated evaluations

## Hallucination Prevention
- **Grounding**: Use `byterover-retrieve-knowledge` pre-generation; chain-of-thought
- **Validation**: Post-gen validate with ByteRover; flag/reprompt low-confidence
- **Guardrails**: Ethical policies; sandbox actions; compliance checks

## ByteRover Workflows

### Onboarding (Universal)
1. `byterover-check-handbook-existence` (create/sync if needed)
2. `byterover-list-modules` (first)
3. `byterover-store-module` for new; `byterover-update-module` for changes
4. Platform: Configure IDE-specific settings and rules

### Planning (Universal)
1. `byterover-retrieve-active-plans`
2. `byterover-save-implementation-plan` on approval
3. `byterover-retrieve-knowledge` per task
4. Ground/validate with ByteRover
5. `byterover-update-plan-progress`
6. Optimize scratchpad.md; Platform: Apply AI assistance

### Memory Bank Update
On "update memory bank":
1. Read all files incl. scratchpad.md
2. `byterover-retrieve-knowledge`
3. Clean garbage/irrelevant/hallucination risks
4. Update all files accurately
5. Sync ByteRover (`byterover-store-knowledge`, `-update-module`)

## MCP Configuration (Universal)
| MCP | Purpose | Priority |
|-----|---------|----------|
| byterover-mcp | Persistent memory | CRITICAL |
| context7 | Library docs | High |
| fetch | Internet retrieval | Medium |
| git | Version control | High |
| mcp-deepwiki | Wiki access | High |
| memory | Persistence | Medium |
| sequential-thinking | Problem solving | High |

## Command Cheatsheet (Universal)
| Command | Description | Tools |
|---------|-------------|-------|
| `clean memory bank` | Clean irrelevant info (max 200 lines/<12K chars) | filesystem + byterover |
| `clean byterover` | Clean irrelevant ByteRover info | byterover-reflect/assess-context |
| `update memory bank` | Update ALL files | filesystem + byterover-store-knowledge |
| `implement next task` | Execute task | git + byterover + read scratchpad.md |
| `platform adapt` | Adapt rules to current IDE | IDE-specific configuration |

## Platform Compatibility Matrix
| IDE | Config File | Rules File | Memory Location |
|-----|------------|------------|-----------------|
| Windsurf | `global_rules.md` | `.windsurfrules` | `.windsurf/memory-bank/` |
| Cursor | `.cursorrules` | `.cursor/rules/*.mdc` | `.cursor/memory-bank/` |
| Cline | VSCode settings | `.clinerules` | `.cline/memory-bank/` |
| Kilo Code | VSCode settings | Custom modes | `.kilocode/memory-bank/` |
| Roo Cline | VSCode settings | `.clinerules-*` | `.roocline/memory-bank/` |
| GitHub Copilot | VSCode settings | `copilot.yaml` | `.copilot/memory-bank/` |
| Zed | `settings.json` | Project settings | `.zed/memory-bank/` |

## Memory Reset Protocol (Universal)
After reset:
1. Read constitution/byterover-rules.md
2. Read all Memory Bank files; focus activeContext/progress
3. Call byterover-retrieve-knowledge/-list-modules/-retrieve-active-plans
4. Platform: Adapt to current IDE configuration

## Critical Success Factors
1. Perfect docs: Bank + ByteRover pristine
2. ByteRover integration
3. Attribution
4. No monoliths
5. Constitutional adherence
6. Context optimization
7. Platform compatibility: Universal rules adapt to any agentic IDE

---
**Remember**: Memory Bank + ByteRover = complete system. Maintain precision for sessions. Universal compatibility across all agentic AI IDEs for maximum flexibility.